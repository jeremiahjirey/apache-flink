import os
import json
import requests
from flask import Flask, render_template

application = Flask(__name__)

API_URL = os.environ.get("TWEET_API_URL")

@application.route("/")
def index():
    tweets = []

    try:
        res = requests.get(API_URL)
        res.raise_for_status()
        data = res.json()

        # Pastikan ini list of dicts
        if isinstance(data, list):
            tweets = data

    except Exception as e:
        print(f"Error fetching tweets: {e}")

    # Buat data agregat untuk chart (contoh: jumlah tweet per user)
    chart_data = {}
    for tweet in tweets:
        user = tweet.get("username", "unknown")
        chart_data[user] = chart_data.get(user, 0) + 1

    return render_template("index.html", tweets=tweets, chart_data=chart_data)


if __name__ == "__main__":
    application.run(debug=True, host="0.0.0.0", port=8000)
