from flask import Flask, render_template, request, redirect
import requests
import os
from collections import Counter

application = Flask(__name__)

API_URL = os.environ.get("TWEET_API_URL")

@application.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        username = request.form.get("username")
        content = request.form.get("content")
        if username and content:
            try:
                requests.post(API_URL, json={
                    "username": username,
                    "content": content
                })
            except Exception as e:
                return f"Error submitting tweet: {e}", 500
        return redirect("/")

    try:
        response = requests.get(API_URL)
        tweets = response.json()

        user_counts = Counter(tweet["username"] for tweet in tweets)
        chart_labels = list(user_counts.keys())
        chart_values = list(user_counts.values())

        return render_template(
            "index.html",
            tweets=tweets,
            chart_labels=chart_labels,
            chart_values=chart_values
        )
    except Exception as e:
        return f"Error: {e}", 500

if __name__ == "__main__":
    application.run(debug=True, host="0.0.0.0", port=8000)
